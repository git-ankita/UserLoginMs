package com.micros1.ms1;

import org.springframework.data.repository.CrudRepository;

public interface UserRepo extends CrudRepository<User,String>
{

}
