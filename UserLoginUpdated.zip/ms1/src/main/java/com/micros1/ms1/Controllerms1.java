package com.micros1.ms1;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controllerms1
{
	
	@Autowired
	UserRepo usr;
	
	
	
	@RequestMapping("verifyuser")
	public Iterable<User> Verifyuser(User user)
	{
		//return usr.findById(user.getUname());
		//return user;
		return usr.findAll();
		//sSystem.out.println(usr.findById(user.getUname()));
		//return usr.findById(user.getUname());
		//return usr.findAllById(user.getUname());
	}
	
	@RequestMapping("verifyuser1")
	public Optional<User> verifyuser(@RequestBody User user)
	{
		Optional<User> tuser = usr.findById(user.getUname());
		/*System.out.println(user.getUname());
		System.out.println(usr.findById(user.getUname()));
		if(tuser.isPresent())
		{
			System.out.println(user.getPswd());
			System.out.println(tuser.get().getPswd());
			if(tuser.get().getPswd().equals(user.getPswd()))
			{
				
				
				return "success";
			}
			
			return "Failed";
		}*/
		
		return tuser;	
		
	}

	@RequestMapping("/signup")
	public String adduser(@RequestBody User user)
	{
		
		System.out.println(user);
		usr.save(user);
		return "hello "+user.getUname()	;
	}
	
	
	
}
