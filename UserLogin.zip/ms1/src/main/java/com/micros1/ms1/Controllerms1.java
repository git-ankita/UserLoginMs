package com.micros1.ms1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controllerms1
{
	
	@Autowired
	UserRepo usr;
	
	/*@RequestMapping("/login")
	public String home()
	{
		return "login";
	}
	
	@RequestMapping("/processform")
	public String adduser(User user)
	{
		usr.save(user);
		return "success";
	}*/
	
	@RequestMapping("verifyuser")
	public Iterable<User> verifyuser(User user)
	{
		
		System.out.println(usr.findAll());
		return usr.findAll();
	}
	

	
	
	
	
}
