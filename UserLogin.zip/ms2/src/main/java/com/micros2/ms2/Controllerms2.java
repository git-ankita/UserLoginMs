package com.micros2.ms2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@Controller
public class Controllerms2
{
	//@Autowired
	//private RestTemplate rest;
	RestTemplate rest = new RestTemplate();
	
	@RequestMapping("/login")
	public String home()
	{
		return "login";
	}
	
	@RequestMapping("/processform")
	public String Verifyusr(User user)
	{
		int i=0;
		String u1 = user.getUname();
		System.out.println("YYYYYYYYY"+u1);
		String p1 = user.getPswd();
		System.out.println(p1);
		String tempusr=null;
		String u2=null;
		String p2=null;
		tempusr = rest.getForObject("http://localhost:9090/verifyuser", String.class);
		
		//System.out.println("TTTTTTTTTTTT"+tempusr);
		String[] strArr = tempusr.split(",");
		
		  while(i<strArr.length)
		  {
			  u2 =strArr[i++]; 
			  System.out.println("IIIIIIIIII"+u2);
			
	    	  p2 =strArr[i++];
			 
	    	  System.out.println(p2);
	    	  if(u1.equals(u2) && p1.equals(p2))
		    	{
	    		  return "success";
		    	}
		  }
		
		  i=0;
		  return "Failed";
		
		 
	}
	
}
