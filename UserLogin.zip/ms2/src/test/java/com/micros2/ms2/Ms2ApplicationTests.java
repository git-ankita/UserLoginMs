package com.micros2.ms2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ms2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
